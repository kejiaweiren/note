package com.gupao.framework.mybatis;

/**
 * @author qingyin
 * @date 2016/9/25
 */
public interface AutoMapperInteger<T> extends BaseMapper<T, Integer>{
}
