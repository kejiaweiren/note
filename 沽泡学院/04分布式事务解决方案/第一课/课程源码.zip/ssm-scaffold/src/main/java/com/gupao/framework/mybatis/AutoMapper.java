package com.gupao.framework.mybatis;

/**
 */
public interface AutoMapper<T> extends BaseMapper<T, Long> {
	
}
