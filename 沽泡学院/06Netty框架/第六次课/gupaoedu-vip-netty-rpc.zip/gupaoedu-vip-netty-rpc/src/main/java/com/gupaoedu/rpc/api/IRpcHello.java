package com.gupaoedu.rpc.api;

public interface IRpcHello {

	String hello(String name);
	
}
